#!/bin/ksh
FILE="datadump.csv"
echo "USERNAME    : $1"
echo "PASSWORD    : $2"
echo "SERVICENAME : $3"

sqlplus -s "$1/$2@$3" << EOF
SET PAGESIZE 50000
SET COLSEP ","
SET LINESIZE 400
SET FEEDBACK OFF
SET HEADING OFF
SET ECHO OFF
set TRIMSPOOL ON

SPOOL $FILE
SELECT COLUMN1||','||COLUMN2||',' FROM TABLE_NAME;
SPOOL OFF
EXIT
sed -e 's/[\t ]//g;/^$/d' $FILE>$FILE
sed '/^$/d' $FILE> $FILE
EOF

echo "----------------------------------------------------"
echo "Going To Modify Column Datatype"
sqlplus -s "$1/$2@$3" << EOF
DELETE FROM TABLE_NAME;
COMMIT;
ALTER TABLE TABLE_NAME MODIFY (SERVICEALARM_ID varchar2(20));
ALTER SEQUENCE TABLE_NAME MAXVALUE 1E20 CYCLE;
COMMIT;
EXIT
EOF

echo "----------------------------------------------------"
echo "Going To Load Data again to the TABLE_NAME"
sqlplus -s "$1/$2@$3" control=controlfile.ctl <<EOF
EXIT
EOF
rm datadump.csv